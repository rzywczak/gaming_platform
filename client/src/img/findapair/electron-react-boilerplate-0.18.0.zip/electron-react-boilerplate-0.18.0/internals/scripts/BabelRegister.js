const path = require('path');

require('@babel/register')({
  cwd: path.join(__dirname, '..', '..')
});
